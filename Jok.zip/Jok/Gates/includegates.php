<?php

include 'chk.php';
include 'sk.php';
include 'rchk.php';
include 'paypal.php';
include 'auth.php';
include 'mass.php';
include 'chh.php'; 

?>